# CI - Genetic Algorithms for solving the TSP

### Team

- Pau Bosch Coll
- Bernat Comas i Machuca

### Running a script for the first time

These sections show how to run the code to obain the results explained in the report.

1.- Extract the zipped file that contains the source code and the instances folders.

2.- Make sure that the instances folder is in the same directory as the code.Rmd file.

3.- Open the source code file with the R editor, in our case we used RStudio.

4.- Run the initialization cells, and the code should be ready to replicate the results obtained in the report.
    When additional information is needed for any section in the code it is detailed in the text secction next to the code.